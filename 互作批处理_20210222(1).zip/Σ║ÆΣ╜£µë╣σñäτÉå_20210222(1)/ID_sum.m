%{ 
�˳���ֻ����������output��.csv�ļ����㻥���ʲ����ܽ�� 

�������ǰ���ѵõ���output��.csv�ļ�; input�е�lysocsv��endocsvҲӦ׼���ö�Ӧ��.csv�ļ�
ע����������

����������Զ����ɵ�output_sum�ļ�����
%}

%%
clearvars; close all
sumPath = [pwd '\output\'];

lysoPath = [pwd '\input\lysocsv\'];
lyso = dir(fullfile(lysoPath,'*.csv'));
lysolist = strcat(transpose({lyso.folder}),'\',transpose({lyso.name}));
sort(lysolist);

endoPath = [pwd '\input\endocsv\'];
endo = dir(fullfile(endoPath,'*.csv'));
endolist = strcat(transpose({endo.folder}),'\',transpose({endo.name}));
sort(endolist);

outputfile = dir(fullfile(sumPath));
outputfile(1:2,:) = [];
outputlist = strcat(transpose({outputfile.folder}),'\',transpose({outputfile.name}),'\');
sort(outputlist);

lysofull=[];
for csvi = 1:length(lysolist)
    lysoInput = readin(char(lysolist(csvi)));
    lysoSum = lysoInput(size(lysoInput,1),1)+1;
    lysofull = [lysofull;lysoSum]; 
end

endofull=[];
for csvi = 1:length(endolist)
    endoInput = readin(char(endolist(csvi)));
    endoSum = endoInput(size(endoInput,1),1)+1;
    endofull = [endofull;endoSum]; 
end

xlslist=[];
for filei = 1:length(outputlist)
    file = char(outputlist(filei));
    xls = dir(fullfile(file,'*.xls'));
    xlslist = [xlslist;strcat(transpose({xls.folder}),'\',transpose({xls.name}))];
end
sort(xlslist);

itfull=[];
for xlsi = 1:length(xlslist)
    interaction_times = xlsread(char(xlslist(xlsi)));
    itfull = [itfull;size(interaction_times,1)];   
end

lyso_ratio = [];
for ii = 1:length(lysofull)
    lysoratio = itfull(ii)/lysofull(ii);
    lyso_ratio = [lyso_ratio;lysoratio];   
end

endo_ratio = [];
for ii = 1:length(endofull)
    endoratio = itfull(ii)/endofull(ii);
    endo_ratio = [endo_ratio;endoratio];   
end

final_lyso_ratio = sum(lyso_ratio)/length(lyso_ratio);
final_endo_ratio = sum(endo_ratio)/length(endo_ratio);


columns = {'interactionTimes', 'lysoNum', 'endoNum', 'lysoRatio', 'endoRatio', 'lysoPath'};
data = table(itfull, lysofull, endofull, lyso_ratio, endo_ratio, lysolist, 'VariableNames', columns);

mkdir('output_sum');
name = {outputfile.name};
csvname = strcat('output_sum\','FROM_',char(name(1)),'_TO_',char(name(length(name))),'.csv');
% xlsname = strcat('output_onlyFinal\','FROM_',char(name(1)),'_TO_',char(name(length(name))),'.xls');
% lyso_ratio(1,2) = final_ratio;
% xlswrite(xlsname,each_ratio,strcat('A2:B',num2str(size(each_ratio,1)+1)));
% title = {'each ratio','final ratio'};
% xlswrite(xlsname,title,'A1:B1');
writetable(data,csvname);
fprintf('All Done!');

%% 
% ��ȡtrackmate��[TRACK_ID��FRAME��POSITION_X��POSITION_Y]����TRACK_ID����
function coords = readin(file)
spots = xlsread(file);
spots(isnan(spots(:,2)),:) = [];
spots = sortrows(spots,2);
coords = spots(:,[2 8 4 5]);
end

 
